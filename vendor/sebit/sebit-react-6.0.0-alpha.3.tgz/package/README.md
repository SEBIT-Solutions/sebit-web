# @sebit/react

React 18 components of the **SEBIT Design System** — 37 components, one
stylesheet. Dialog, Drawer, Tabs, Switch, Tooltip, Popover and Menu sit on
[Radix UI](https://www.radix-ui.com/primitives) primitives (focus trap, scroll
lock, roving tabindex, `role="switch"`, positioning, `role="menu"`);
Input, Select, Textarea and Checkbox are native elements. Every value is a
`--sb-*` token from `@sebit/design-tokens`; the same `.sb-*` classes style
static HTML.

> Version `6.0.0-alpha.3` — distributed as a GitHub Release, not through a registry (DECISIONS #14).

## Install

Every release of the repository carries the packages as `.tgz` files. Download
them into the application repository, commit them and install from the files:

```sh
gh release download v6.0.0-alpha.3 -R SEBIT-Solutions/sebit-design -p '*.tgz' -D vendor/sebit
npm install ./vendor/sebit/sebit-design-tokens-6.0.0-alpha.3.tgz ./vendor/sebit/sebit-react-6.0.0-alpha.3.tgz
```

Committed tarballs keep the application's CI independent of access to this
repository. To upgrade, download the next release and install its files over
the old ones. Inside this monorepo the packages are npm workspaces.

Peer dependencies: `react` and `react-dom` `^18.2.0`.

## Use

```tsx
import '@sebit/design-tokens/css';   // tokens, aliases, Inter @font-face — first
import '@sebit/react/styles.css';    // every .sb-* component class

import { useState } from 'react';
import { Button, Field, Input, Dialog } from '@sebit/react';

export function Poptavka() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Field label="E-mail" helper="Firemní adresa." required>
        <Input type="email" />
      </Field>
      <Button onClick={() => setOpen(true)}>Probrat projekt</Button>
      <Dialog open={open} title="Odeslat poptávku?" onClose={() => setOpen(false)}
        footer={<Button onClick={() => setOpen(false)}>Odeslat poptávku</Button>}>
        <p>Ozveme se do dvou pracovních dnů.</p>
      </Dialog>
    </>
  );
}
```

Copy is Czech, vykání, sentence case; the rules are in the Agent contract
(`README.md` at the repository root). Every control belongs in a `Field`: it
generates the ids and wires `aria-describedby`, `aria-invalid` and
`aria-required` to the control.

### Only some components

`styles.css` is `css/base.css` followed by every `css/<Comp>.css`. To ship
less CSS, import `base.css` and the components you use:

```ts
import '@sebit/react/css/base.css';
import '@sebit/react/css/Button.css';
import '@sebit/react/css/Field.css';
```

`"sideEffects": ["*.css"]` keeps the stylesheets through tree shaking; the JS
is side-effect free. There is no runtime `<style>` injection in the package.

## Next.js (App Router)

The built `dist/index.mjs` / `dist/index.cjs` start with `"use client"`, so
the components can be imported straight into Server Components. Import the
two stylesheets once in `app/layout.tsx`:

```tsx
// app/layout.tsx
import '@sebit/design-tokens/css';
import '@sebit/react/styles.css';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="cs">
      <body>{children}</body>
    </html>
  );
}
```

Inter is self-hosted by `@sebit/design-tokens` (DECISIONS #13) — do not add a
`next/font/google` call.

## Theming

Light is the default. Dark mode switches every semantic token, so the
components follow without extra classes:

```html
<html lang="cs" data-theme="dark">
```

Set `data-theme="light"` or `"dark"` on any subtree to scope it. Never style a
component with a primitive (`--sb-navy-*`, `--sb-grey-*`): primitives do not
switch.

## Static HTML

The same classes work without React: `.sb-<comp>`, modifiers
`.sb-<comp>--<modifier>`, parts `.sb-<comp>__<part>`. Each component's
markup is in `components/<Comp>/README.md` § Static HTML. In this repository
`styles.css` already includes `components/sb-components.css` (a generated copy of
`dist/styles.css`); elsewhere link `@sebit/design-tokens/css` and
`@sebit/react/styles.css` (or their `dist` files). Behaviour — dialogs, tabs,
dismissing — needs React or a script of your own.

## Classes

| Component | Root class | Modifiers |
|---|---|---|
| Button | `.sb-button` | `--primary` `--ghost` `--lime` `--danger` `--sm` `--lg` `--on-navy` `--block` `--shadow` |
| Badge | `.sb-badge` | `--neutral` `--brand` `--accent` `--success` `--warning` `--danger` `--info` `--pill` |
| Field | `.sb-field` | `--inline` `--error` `--success` |
| Input / Textarea | `.sb-input` / `.sb-textarea` | `.sb-input--sm`; error via `aria-invalid="true"` |
| Select | `.sb-select` + `.sb-select__control` | `--sm` |
| Checkbox | `.sb-checkbox` | `--radio` `--disabled` |
| Switch | `.sb-switch` | `--disabled` |
| Alert | `.sb-alert` | `--info` `--success` `--warning` `--danger` `--banner` `--solid` |
| Toast / ToastStack | `.sb-toast` / `.sb-toast-stack` | tones; stack `--top-right` `--bottom-right` `--bottom-left` `--top-left` |
| Dialog / Drawer | `.sb-dialog` / `.sb-drawer` | `--sm` `--lg` / `--left` `--right` |
| Table / DataList | `.sb-table` / `.sb-data-list` | `--compact` `--zebra` |
| Tabs / Breadcrumb | `.sb-tabs` / `.sb-breadcrumb` | `--pills` |
| EmptyState / Skeleton | `.sb-empty-state` / `.sb-skeleton` | `--plain` / `--text` `--circle` `--card` `--lines` |
| Card / Stack | `.sb-card` / `.sb-stack` | `--raised` `--flat` `--navy` `--interactive` / `--vertical` `--horizontal` `--wrap` |
| Tooltip / Popover / Menu | `.sb-tooltip` / `.sb-popover` / `.sb-menu` | menu item `--danger` |
| Progress | `.sb-progress` | `--brand` `--success` `--warning` `--danger` `--sm` `--indeterminate` |
| KpiCard / Avatar | `.sb-kpi` / `.sb-avatar` | `--navy`, delta `--good` `--bad` `--flat` / `--sm` `--lg` |
| Pagination | `.sb-pagination` | page `--current` |
| RadioGroup / DateInput | `.sb-radio-group` / `.sb-date-input` (on `.sb-input`) | `--horizontal` |
| Combobox | `.sb-combobox` | `--sm` `--open`; option `--active` `--selected` |
| FileUpload | `.sb-file-upload` | `--dragging` `--disabled` |
| Stepper | `.sb-stepper` | `--vertical`; step `--done` `--current` `--ahead` |
| AppShell / SideNav / TopBar / PageHeader | `.sb-app-shell` / `.sb-sidenav` / `.sb-topbar` / `.sb-page-header` | main `--wide` `--none`; item `--current` |

Shared helpers in `base.css`: `.sb-icon` (sprite glyphs, `1em`, stroke 1.75),
`.sb-close` (dismiss button), `.sb-visually-hidden`.

## Icons

The components draw the core UI glyphs they need (`alert`, `arrow-up-right`,
`check`, `check-circle`, `chevron-down`, `close`, `document`, `folder`, `info`, `menu`) inline, copied at
build time from `assets/icons/_sebit-ui-icons.svg` into
`src/internal/icons.ts` — no sprite URL to configure. Your own icons come from
the sprites: `<svg class="sb-icon" aria-hidden="true"><use href="…/_sebit-ui-icons.svg#i-arrow-right"/></svg>`.

## Develop

From the repository root:

```sh
npm ci
npm run build:react                 # dist/: index.mjs, index.cjs, index.d.ts, styles.css, css/*
npm run build:page                  # components/bundle.js, components/index.d.ts, components/sb-components.css, src/internal/icons.ts
npm test -w @sebit/react            # Vitest + Testing Library + axe-core
npm run typecheck -w @sebit/react   # strict TypeScript, tests included
```

Sources: `src/<Comp>/<Comp>.tsx`, `<Comp>.css`, `<Comp>.test.tsx`; the list
and order live in `components.cjs`. Only `var(--sb-*)` tokens in CSS — no hex,
no px radius, no invented token (`npm run lint:ui` runs `ai/check.cjs` over
`src`). After any change run `npm run build:page`: `npm run check` fails while
`components/bundle.js` or `components/index.d.ts` are stale.

## Licence

Internal — see `LICENSE`.
