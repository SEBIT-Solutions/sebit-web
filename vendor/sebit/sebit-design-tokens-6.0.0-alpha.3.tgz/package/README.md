# @sebit/design-tokens

Design tokens for the **SEBIT Design System** — single source of truth
for color, type, spacing, radii, shadows, motion, and z-index across the
five SEBIT public surfaces (Solutions · Labs · Medical · Academy ·
Manifest).

> One source (`tokens.json`), packaged as-is: the same `tokens.css` and
> aliases the Design System page uses, with light and dark themes,
> reduced motion and self-hosted Inter. No second generator, so the
> package cannot drift from the system.

## Install

```sh
gh release download v6.0.0-alpha.3 -R SEBIT-Solutions/sebit-design -p '*.tgz' -D vendor/sebit
npm install ./vendor/sebit/sebit-design-tokens-6.0.0-alpha.3.tgz
```

The package is distributed as a file on every GitHub Release of the
repository, not through a registry (DECISIONS #14). Commit the downloaded
`.tgz` in the application repository. Inside this monorepo it is an npm
workspace.

## Outputs

| Import | File | For |
|---|---|---|
| `@sebit/design-tokens/css` | `index.css` | **Start here.** Tokens + aliases, one import |
| `@sebit/design-tokens/tokens.css` | `tokens.css` | Every `--sb-*` token, `:root` + `[data-theme="dark"]`, Inter `@font-face` |
| `@sebit/design-tokens/aliases.css` | `aliases.css` | Radius, elevation, spacing, motion, focus-ring aliases; `prefers-reduced-motion` |
| `@sebit/design-tokens/fonts/*` | `fonts/Inter-*.woff2` | Referenced by `tokens.css` — bundlers copy them |
| `@sebit/design-tokens` | `index.mjs` / `index.cjs` / `index.d.ts` | `tokens` (resolved values, `tokens.themes.light` / `.dark`), `cssVar()`, type `SbToken` |
| `@sebit/design-tokens/scss` | `_tokens.scss` | `$sb-*: var(--sb-*)` |
| `@sebit/design-tokens/tailwind` | `tailwind.css` | Optional: Tailwind v4 `@theme` mapping onto the variables |
| `@sebit/design-tokens/tailwind-preset` | `tailwind-preset.cjs` | Optional: Tailwind v3 preset, same mapping |
| `@sebit/design-tokens/json` | `tokens.json` | The source of truth (usage notes, contrast, themes) |
| `@sebit/design-tokens/assets/{logos,icons,favicon,og}/*` | `assets/` | Brand files: logos (outlined SVG), icon sprites, favicon, Open Graph cards (PNG + SVG). Copy them into the site's public folder at build time; never redraw (DECISIONS #15). |
| `@sebit/design-tokens/ai/check.cjs` | `ai/check.cjs` | The Agent-contract checker of this release: `node node_modules/@sebit/design-tokens/ai/check.cjs src/` (exit 1 on an error). `ai/AGENTS.snippet.txt` is the rules block for a consumer's `AGENTS.md`. |
| `@sebit/design-tokens/powerbi/sebit-light.json` · `sebit-dark.json` | `powerbi/*.json` | Power BI report themes: series = `--sb-chart-1…8` in order, good / neutral / bad = status tokens, surfaces and text from the theme. Import in Power BI Desktop → View → Themes → Browse. Inter falls back to Segoe UI where it is not installed. |

Tailwind classes resolve to `var(--sb-*)`, so dark mode and any later theme
follow `data-theme` without a rebuild: `bg-bg-inverse`, `text-fg-brand`,
`rounded-button`, `shadow-elevation-card`.

## Usage

### CSS

```css
@import "@sebit/design-tokens/css";

.panel {
  background: var(--sb-bg-surface);
  color: var(--sb-fg-default);
  border-radius: var(--sb-radius-card);
}
```

Dark theme: `<html data-theme="dark">`.

### TypeScript

```ts
import { tokens, cssVar, type SbToken } from '@sebit/design-tokens';

const brand: SbToken = '--sb-fg-brand';
el.style.color = cssVar(brand);                 // follows the theme
const navy = tokens.color.navy['700'];           // '#002b5c' — static targets only (charts, PDFs)
```

Prefer `cssVar()`. Resolved values do not follow the theme.

## Versioning

Strict [semver](https://semver.org/):

- **major** — a token is renamed, removed, or its semantic meaning changes
  (e.g. `--sb-fg-brand` swaps from navy to lime).
- **minor** — a new token is added; an existing value bumps to a new
  visually equivalent value (≤ ΔE 2 in OKLCH).
- **patch** — comment / metadata only, no runtime impact.

CHANGELOG: see `../../CHANGELOG.md` at the monorepo root.

## License

SEBIT internal — see `./LICENSE`. Inter binaries shipped from
`fonts/Inter-*.woff2` carry their own SIL OFL 1.1 license; see
`fonts/OFL.txt` in the monorepo root.
